﻿using UnityEngine;


public class FirstScript : MonoBehaviour {


	void Start () {


	}
	
	// Update is called once per frame
	void Update () {



	}




}


