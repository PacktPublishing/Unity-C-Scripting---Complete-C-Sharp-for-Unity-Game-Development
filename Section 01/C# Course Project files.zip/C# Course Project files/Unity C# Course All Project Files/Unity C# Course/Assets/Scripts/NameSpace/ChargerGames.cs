﻿using UnityEngine;

namespace ChargerGames
{

    public class Utilites
    {

        public static void PrintCharger()
        {
            Debug.Log("Charger Games");
        }
    }


    namespace UI
    {

        public class UIStuff
        {

            public static void DoUI()
            {
                Debug.Log(" Do UI()");
            }

        }

    }



}