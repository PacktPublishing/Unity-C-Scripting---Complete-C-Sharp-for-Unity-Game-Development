﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using ChargerGames;
using ChargerGames.UI;

public class NameSpaceTest : MonoBehaviour {

	// Use this for initialization
	void Start ()
    {

        Utilites.PrintCharger();

        UIStuff.DoUI();
       
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
